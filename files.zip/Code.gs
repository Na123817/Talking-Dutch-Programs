/**
 * Talking Dutch — A1-A2 tracker sync backend
 * Deploy: Extensies > Apps Script in je Sheet, plak dit script erin,
 * dan Implementeren > Nieuwe implementatie > Web app > "Iedereen" toegang.
 */

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName('Voortgang');
  if (!sheet) sheet = ss.getActiveSheet();
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(['Student', 'Module', 'Sessie', 'Type', 'Sessienummer', 'Voltooid', 'Notitie', 'Laatst bijgewerkt']);
  }
  return sheet;
}

function upsertRow_(sheet, item) {
  const student = (item.student || 'Onbekend').toString();
  const mod = Number(item.mod);
  const ses = Number(item.ses);
  const rowData = [
    student,
    mod,
    ses,
    item.type || '',
    item.sesNum || '',
    item.checked ? 'Ja' : 'Nee',
    item.note || '',
    new Date()
  ];

  const lastRow = sheet.getLastRow();
  let rowIndex = -1;
  if (lastRow > 1) {
    const values = sheet.getRange(2, 1, lastRow - 1, 3).getValues(); // Student, Module, Sessie
    for (let i = 0; i < values.length; i++) {
      if (values[i][0] === student && Number(values[i][1]) === mod && Number(values[i][2]) === ses) {
        rowIndex = i + 2;
        break;
      }
    }
  }

  if (rowIndex > -1) {
    sheet.getRange(rowIndex, 1, 1, rowData.length).setValues([rowData]);
  } else {
    sheet.appendRow(rowData);
  }
}

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const sheet = getSheet_();
    const items = data.batch ? data.batch : [data];
    items.forEach(function (item) { upsertRow_(sheet, item); });
    return ContentService
      .createTextOutput(JSON.stringify({ status: 'ok', count: items.length }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  return ContentService
    .createTextOutput(JSON.stringify({ status: 'A1-A2 sync endpoint actief' }))
    .setMimeType(ContentService.MimeType.JSON);
}
